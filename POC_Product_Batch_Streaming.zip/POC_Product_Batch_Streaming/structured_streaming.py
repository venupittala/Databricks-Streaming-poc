# Databricks notebook source
# MAGIC %md
# MAGIC ###`Product Data POC  on Structured Streaming`
# MAGIC 
# MAGIC `This notebook we are using for to do POC on structured Streaming `:
# MAGIC * Reading multiple csv files using structured streaming 
# MAGIC * Steaming data load of weather data using delta table
# MAGIC 
# MAGIC 
# MAGIC ###Details
# MAGIC | Details | Information
# MAGIC | - | -  
# MAGIC | Notebook Created By | Venu Pittala 
# MAGIC | Object Name | product data analysis
# MAGIC | File Type | delimited file
# MAGIC | Target Location | Databricks Delta Table 
# MAGIC 
# MAGIC ###History
# MAGIC |Date | Developed By | comments
# MAGIC |----|-----|----
# MAGIC |16/12/2022|Venu| Initial Version

# COMMAND ----------

# MAGIC %md
# MAGIC #### calling `common` notebook for metadata and other variables

# COMMAND ----------

# MAGIC %run ./config_streaming

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating pyspark schema for reading csv files.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Creating streaming dataframe using `maxFilesPerTrigger 1 option`

# COMMAND ----------

from pyspark.sql.functions import *

# Similar to definition of staticInputDF above, just using `readStream` instead of `read`
streamingInputDF = spark.readStream.schema(streamSchema).option("maxFilesPerTrigger", 1).csv(streaming_path,header=True,sep="\t")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Validating is above created dataframe is Streaming dataframe or not

# COMMAND ----------

if streamingInputDF.isStreaming==True:
  print(' streamingInputDF is Streaming Dataframe')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Perform the following transformations
# MAGIC ###### a.	Drop the following columns :  record_min_temp_year, record_max_temp_year
# MAGIC ###### b.	Filter out records with actual_precipitation = 0
# MAGIC ###### c.	Create a new column deviation_from_avg = abs(actual_precipitation – average_precipitation)

# COMMAND ----------

from pyspark.sql.functions import abs,col,lit,current_date,date_format
finalStreamingDF = streamingInputDF.drop("record_min_temp_year","record_max_temp_year")\
                  .filter("actual_precipitation ==0")\
                  .withColumn("deviation_from_avg",abs(col("actual_precipitation")-col("average_precipitation")))\
                  .withColumn("year",date_format(to_date("date","dd-MM-yyyy"),'yyyy'))\
                  .withColumn("month",date_format(to_date("date","dd-MM-yyyy"),'MM'))

# COMMAND ----------

writedf = finalStreamingDF.writeStream.format("delta").partitionBy("year","month").outputMode("append").option("checkpointLocation", "/tmp/_checkpoints/streaming").start("/tmp/streaming")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Stop Streaming using `stop()` method

# COMMAND ----------

import time
time.sleep(5*60) #this will stop the program for 5 minutes
writedf.stop()

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from delta.`/tmp/streaming`

# COMMAND ----------

# MAGIC %fs ls /tmp/streaming/year=2014/month=07/