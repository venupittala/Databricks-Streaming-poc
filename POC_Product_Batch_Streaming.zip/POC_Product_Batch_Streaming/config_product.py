# Databricks notebook source
# MAGIC %md
# MAGIC #### Creating `product` Delta table using DDL Script

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS product;
# MAGIC CREATE  TABLE IF NOT EXISTS `product` (
# MAGIC   `productCode` STRING,
# MAGIC   `productName` STRING,
# MAGIC   `productLine` STRING,
# MAGIC   `productScale` STRING,
# MAGIC   `productVendor` STRING,
# MAGIC   `productDescription` STRING,
# MAGIC   `quantityInStock` INT,
# MAGIC   `buyPrice` DOUBLE,
# MAGIC   `MSRP` DOUBLE,
# MAGIC   `createdDate` TIMESTAMP,
# MAGIC   `createdBy` STRING,
# MAGIC   `updatedDate` TIMESTAMP,
# MAGIC   `updatedBy` STRING)
# MAGIC USING delta;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating `pyspark Schema` for product table to avoid datatypes issues while reading data.

# COMMAND ----------

from pyspark.sql.types import StringType,IntegerType,DoubleType,StructField,StructType
product_schema= StructType([StructField("productCode",StringType(),True),
                            StructField("productName",StringType(),True),
                            StructField("productLine",StringType(),True),
                            StructField("productScale",StringType(),True),
                            StructField("productVendor",StringType(),True),
                            StructField("productDescription",StringType(),True),
                            StructField("quantityInStock",IntegerType(),True),
                            StructField("buyPrice",DoubleType(),True),
                            StructField("MSRP",DoubleType(),True)])

# COMMAND ----------

product_badpath="/tmp/productsBadPath/"
product_source_file="dbfs:/FileStore/products/product.txt"
product_delimiter="\t"
product_delta_file="dbfs:/FileStore/products/product_delta.txt"

# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/product.txt","/tmp/product.txt")
dbutils.fs.mv("file:/tmp/product.txt","dbfs:/FileStore/products/product.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/product_delta.txt","/tmp/product_delta.txt")
dbutils.fs.mv("file:/tmp/product_delta.txt","dbfs:/FileStore/products/product_delta.txt")
print('product files copied to ',product_source_file)
print('product delta files copied to ',product_delta_file)

# COMMAND ----------

# import urllib.request
# urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/poc_product/product.txt","/tmp/product.txt")
# dbutils.fs.mv("file:/tmp/product.txt","dbfs:/FileStore/products/product.txt")
# urllib.request.urlretrieve("https://raw.githubusercontent.com/raveendratal/PysparkTelugu/master/poc_product/product_delta.txt","/tmp/product_delta.txt")
# dbutils.fs.mv("file:/tmp/product_delta.txt","dbfs:/FileStore/products/product_delta.txt")
# print('product files copied to ',product_source_file)
# print('product delta files copied to ',product_delta_file)