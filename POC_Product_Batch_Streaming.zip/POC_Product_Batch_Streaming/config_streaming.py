# Databricks notebook source
# MAGIC %md
# MAGIC ##### Creating pyspark schema for reading csv files.

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
streamSchema = StructType([StructField("date",StringType(),True),
                         StructField("actual_mean_temp",IntegerType(),True),
                         StructField("actual_min_temp",IntegerType(),True),
                         StructField("actual_max_temp",IntegerType(),True),
                         StructField("average_min_temp",IntegerType(),True),
                         StructField("average_max_temp",IntegerType(),True),
                         StructField("record_min_temp",IntegerType(),True),
                         StructField("record_max_temp",IntegerType(),True),
                         StructField("record_min_temp_year",IntegerType(),True),
                         StructField("record_max_temp_year",IntegerType(),True),
                         StructField("actual_precipitation",DoubleType(),True),
                         StructField("average_precipitation",DoubleType(),True),
                         StructField("record_precipitation",DoubleType(),True)])

# COMMAND ----------

product_delimiter="\t"
streaming_path="dbfs:/FileStore/streaming"


# COMMAND ----------

import urllib.request
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws01.txt","/tmp/ws01.txt")
dbutils.fs.mv("file:/tmp/ws01.txt","dbfs:/FileStore/streaming/ws01.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws02.txt","/tmp/ws02.txt")
dbutils.fs.mv("file:/tmp/ws02.txt","dbfs:/FileStore/streaming/ws02.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws03.txt","/tmp/ws03.txt")
dbutils.fs.mv("file:/tmp/ws03.txt","dbfs:/FileStore/streaming/ws03.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws04.txt","/tmp/ws04.txt")
dbutils.fs.mv("file:/tmp/ws04.txt","dbfs:/FileStore/streaming/ws04.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws05.txt","/tmp/ws05.txt")
dbutils.fs.mv("file:/tmp/ws05.txt","dbfs:/FileStore/streaming/ws05.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws06.txt","/tmp/ws06.txt")
dbutils.fs.mv("file:/tmp/ws06.txt","dbfs:/FileStore/streaming/ws06.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws07.txt","/tmp/ws07.txt")
dbutils.fs.mv("file:/tmp/ws07.txt","dbfs:/FileStore/streaming/ws07.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws08.txt","/tmp/ws08.txt")
dbutils.fs.mv("file:/tmp/ws08.txt","dbfs:/FileStore/streaming/ws08.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws09.txt","/tmp/ws09.txt")
dbutils.fs.mv("file:/tmp/ws09.txt","dbfs:/FileStore/streaming/ws09.txt")
urllib.request.urlretrieve("https://raw.github.com/venupittala/Databricks-Streaming-poc/master/poc_product/streaming_files/ws10.txt","/tmp/ws10.txt")
dbutils.fs.mv("file:/tmp/ws10.txt","dbfs:/FileStore/streaming/ws10.txt")
print('weather streamings files copied to :',streaming_path)