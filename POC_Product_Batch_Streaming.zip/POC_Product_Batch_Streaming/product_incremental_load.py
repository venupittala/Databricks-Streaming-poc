# Databricks notebook source
# MAGIC %md
# MAGIC ###`Product Data POC  on Incremental Load`
# MAGIC 
# MAGIC `This notebook we are using for to do POC on incremental load and Streaming `:
# MAGIC * Reading Product data csv file
# MAGIC * Creating and loading Product data as a delta table
# MAGIC * Incremental data load for product delta table
# MAGIC * Steaming data load of weather data using delta table
# MAGIC 
# MAGIC 
# MAGIC ###Details
# MAGIC 
# MAGIC | Details | Information 
# MAGIC |----|-----
# MAGIC |Notebook Created By | Venu Pittala 
# MAGIC |Object Name | product data analysis
# MAGIC |File Type | delimited file
# MAGIC |Target Location | Databricks Delta Table 
# MAGIC 
# MAGIC ###History
# MAGIC |Date | Developed By | comments
# MAGIC |----|-----|----
# MAGIC |16/12/2022|Venu| Initial Version

# COMMAND ----------

# MAGIC %md
# MAGIC #### call common notebook which contains pyspark schema and ddl's

# COMMAND ----------

# MAGIC %run ./config_product

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating product dataframe for reading existing file  and applying pyspark schema.
# MAGIC * specifying `badRecordsPath` to store rejected data in datalake.
# MAGIC * specifying `schema` option while reading csv file.

# COMMAND ----------

df_product = spark.read.schema(product_schema).option("badRecordsPath", product_badpath).csv(product_source_file,header=True,sep=product_delimiter)
df_product.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #### applying Transformations on product dataframe
# MAGIC * applying `dropDuplicates` based on productCode and removing duplicates if any.
# MAGIC * adding audit columns for data audinting.

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit
df_unique = df_product.dropDuplicates(["productCode"])
df_unique = df_unique.withColumn("createdDate",lit(current_timestamp()))\
                     .withColumn("createdBy",lit("Databricks_Job"))\
                     .withColumn("updatedDate",lit(None))\
                     .withColumn("updatedBy",lit(""))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Validating data with existing table. if data is available just ingonring full load data.
# MAGIC * creating dataframe selecting existing data and applying `left anti join` to filter existing data

# COMMAND ----------

df_product_main = spark.table("product")
df_final = df_unique.join(df_product_main,df_product_main["productCode"]==df_unique["productCode"],'anti')

# COMMAND ----------

df_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Writing data into product delta table

# COMMAND ----------

df_final.write.format("delta").option("mergeSchema","true").mode("append").saveAsTable("product")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Reading existing product delta table data for incremental data process.

# COMMAND ----------

df_product_main = spark.table("product")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Reading incremental datafile

# COMMAND ----------

df_product_incremental = spark.read.csv(product_delta_file,header=True,sep=product_delimiter)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Applying incremental load on product delta table based on incremental data.
# MAGIC * if records are available for productCode combination it will update.
# MAGIC * if records are not available for productcode combination then it will insert.

# COMMAND ----------

from delta.tables import *
deltaTable = DeltaTable.forPath(spark, "/user/hive/warehouse/product/")

deltaTable.alias("tgt").merge(\
  df_product_incremental.alias("src"),\
    "tgt.productCode = src.productCode") \
  .whenMatchedUpdate(set = { "productCode": "src.productCode",
      "productName": "src.productName",
      "productLine": "src.productLine",
      "productScale": "src.productScale",
      "productVendor": "src.productVendor",
      "productDescription": "src.productDescription",
      "quantityInStock": "src.quantityInStock",
      "buyPrice": "src.buyPrice",
      "MSRP": "src.MSRP",
      "updatedDate": current_timestamp(),
      "updatedBy": lit("Databricks_Job") } ) \
  .whenNotMatchedInsert(values =
    {
      "productCode": "src.productCode",
      "productName": "src.productName",
      "productLine": "src.productLine",
      "productScale": "src.productScale",
      "productVendor": "src.productVendor",
      "productDescription": "src.productDescription",
      "quantityInStock": "src.quantityInStock",
      "buyPrice": "src.buyPrice",
      "MSRP": "src.MSRP",
      "createdDate": current_timestamp(),
      "createdBy": lit("Databricks_Job")
    }
  ) \
  .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from product